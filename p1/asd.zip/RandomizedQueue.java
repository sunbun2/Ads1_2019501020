import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdRandom;
import java.util.NoSuchElementException;
import java.util.Iterator;
import java.util.Arrays;
public class RandomizedQueue<Item> implements Iterable<Item>  {
    private Item[] arr;
    private int size;
    public RandomizedQueue() {
        arr = (Item[]) new Object[10];
        size = 0;
    }

    private void resize() {
        Item[] tempKeys = Arrays.copyOf(this.arr, this.arr.length * 2);
        this.arr = tempKeys;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    // return the number of items on the randomized queue
    public int size() {
        return size;
    }

    // add the item
    public void enqueue(Item item) {
        if (item == null) throw new IllegalArgumentException();
        if (size >= arr.length/2) { resize(); }
        arr[size++] = item;
        
    }

    // remove and return a random item
    public Item dequeue() {
        if (size == 0) throw new java.util.NoSuchElementException(); 
        int a = StdRandom.uniform(size);
        Item b = arr[a];  
        for (int j = a; j < size; j++) {
            arr[j] = arr[j+1];
        }
        arr[size] = null;
        size--;
        return b;
    }

    // return a random item (but do not remove it)
    public Item sample() {
        if (size == 0) throw new java.util.NoSuchElementException(); 
        int u = StdRandom.uniform(size);
        return arr[u];  
    }
    public Iterator<Item> iterator() {
        return new RandomArrayIterator();
    }

    private class RandomArrayIterator implements Iterator<Item> {
        private Item[] r;
        private int i;

        public RandomArrayIterator() {
            copyQueue();
            StdRandom.shuffle(r);
        }

        private void copyQueue() {
            r = (Item[]) new Object[size];
            for (int i = 0; i < size; i++) {
                r[i] = arr[i];
            }
        }

        public boolean hasNext() {
            return i < size;
        }

        public void remove() {
            throw new UnsupportedOperationException();
        }

        public Item next() {
            if (!hasNext()) throw new NoSuchElementException();
            return r[i++];
        }
    }
    // unit testing (required)
    public static void main(String[] args) {
        RandomizedQueue<Integer> a = new RandomizedQueue();
        a.enqueue(896);
        a.enqueue(564);
        a.enqueue(326);
        a.enqueue(751);
        System.out.println(a.dequeue());
        System.out.println(a.dequeue());
        System.out.println(a.dequeue());
        System.out.println(a.dequeue());
        
        // System.out.println(a.size());
        // System.out.println(a.isEmpty());
        // System.out.println(a.sample());
        // System.out.println(a.dequeue());
    }
}